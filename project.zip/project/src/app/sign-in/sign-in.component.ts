import { Component, OnInit } from '@angular/core';
// import { AngularFireAuth } from 'angularfire2/auth'; 
// import firebase from 'firebase/app'; 
@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent {

  constructor(/*private afAuth: AngularFireAuth*/) { }

  login() { 
    /*this.afAuth.auth.signInWithRedirect(new firebase.auth.GoogleAuthProvider());*/
  }

}
