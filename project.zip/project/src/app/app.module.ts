import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// import { AngularFireModule } from 'angularfire2';
// import { AngularFireDatabaseModule } from 'angularfire2/database';
// import { AngularFireAuthModule } from 'angularfire2/auth';
import { RouterModule } from '@angular/router'
import { AppComponent } from './app.component';
import { BsNavbarComponent } from './bs-navbar/bs-navbar.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { HomeComponent } from './home/home.component';
import { PostComponent } from './post/post.component';
// import { environment } from 'src/environments/environment';

// const firebaseConfig = {
//   apiKey: "AIzaSyARXWcFqLBbsN7pohKZ8j8a7Xe_asT8ZVI",
//   authDomain: "oneclickdilevryapp.firebaseapp.com",
//   projectId: "oneclickdilevryapp",
//   storageBucket: "oneclickdilevryapp.appspot.com",
//   messagingSenderId: "795137448607",
//   appId: "1:795137448607:web:5fd4768c6461b4c80b60aa",
//   measurementId: "G-D9E3D79503"
// };

@NgModule({
  declarations: [
    AppComponent,
    BsNavbarComponent,
    SignUpComponent,
    SignInComponent,
    HomeComponent,
    PostComponent
  ],
  imports: [
    BrowserModule,
    NgbModule,
    RouterModule.forRoot([
      {path:'',component:HomeComponent},
      {path:'sign-in',component:SignInComponent},
      {path:'sign-up',component:SignUpComponent},
      {path:'post',component:PostComponent}
    ]),
    // AngularFireModule.initializeApp(environment.firebase),
    // AngularFireDatabaseModule,
    // AngularFireAuthModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
